# -*- coding: utf-8 -*-
from __future__ import absolute_import,unicode_literals
def get_data():
	"""เป็นคำสั่งสำหรับตัววรรณยุกต์ในภาษาไทย
	คืนค่า list
	"""
	return [u'่',u'้',u'๊',u'๋']