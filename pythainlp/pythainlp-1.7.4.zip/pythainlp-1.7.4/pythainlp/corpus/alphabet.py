﻿# -*- coding: utf-8 -*-
from __future__ import absolute_import,unicode_literals
def get_data():
	"""เป็นคำสั่งสำหรับดึงตัวอักษร ก - ฮ ในภาษาไทย
	คืนค่า list
	"""
	return [u"ก",u"ข",u"ฃ",u"ค",u"ฅ",u"ฆ",u"ง",u"จ",u"ฉ",u"ช",u"ซ",u"ฌ",u"ญ",u"ฎ",u"ฏ",u"ฐ",u"ฑ",u"ฒ",u"ณ",u"ด",u"ต",u"ถ",u"ท",u"ธ",u"น",u"บ",u"ป",u"ผ",u"ฝ",u"พ",u"ฟ",u"ภ",u"ม",u"ย",u"ร",u"ล",u"ว",u"ศ",u"ษ",u"ส",u"ห",u"ฬ",u"อ",u"ฮ"]
