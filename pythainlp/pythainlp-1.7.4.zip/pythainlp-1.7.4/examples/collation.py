# -*- coding: utf-8 -*-

from pythainlp.collation import collation

print(collation(["ไก่", "ไข่", "ก", "ฮา"]))  # ['ก', 'ไก่', 'ไข่', 'ฮา']
