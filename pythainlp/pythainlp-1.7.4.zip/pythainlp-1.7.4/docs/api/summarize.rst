.. currentmodule:: pythainlp.summarize

pythainlp.summarize
====================================
The :class:`summarize` is thai text summarize.

Modules
-------

.. autofunction:: summarize_text
