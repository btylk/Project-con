.. currentmodule:: pythainlp.spell

pythainlp.spell
=====================================
The :class:`pythainlp.spell` finds the closest correctly spelled word to the given text.

.. autofunction:: spell
