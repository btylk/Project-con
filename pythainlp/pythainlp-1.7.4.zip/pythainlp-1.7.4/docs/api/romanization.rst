.. currentmodule:: pythainlp.romanization

pythainlp.romanization
====================================
The :class:`romanization.romanization` turns thai text into a romanized one (put simply, spelled with English).

.. autofunction:: romanization
.. currentmodule:: pythainlp.romanization.thai2rom
.. autoclass:: thai2rom
   :members: romanization
