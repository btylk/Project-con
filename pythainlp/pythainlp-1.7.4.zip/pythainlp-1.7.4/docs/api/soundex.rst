.. currentmodule:: pythainlp.soundex

pythainlp.soundex
====================================
The :class:`pythainlp.soundex` is soundex for thai.

.. autofunction:: LK82
.. autofunction:: Udom83