.. currentmodule:: pythainlp.number

pythainlp.number
=====================================
The :class:`pythainlp.number` contains functions for processing thai numbers and thai words that refers to numbers.

.. autofunction:: thai_num_to_num
.. autofunction:: thai_num_to_text
.. autofunction:: num_to_thai_num
.. autofunction:: num_to_text
.. autofunction:: text_to_num
.. autofunction:: numtowords



