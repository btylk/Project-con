.. currentmodule:: pythainlp.ner

pythainlp.ner
====================================
The :class:`pythainlp.ner` is named entity recognition for thai.


Modules
-------

.. autoclass:: thainer
   :members: get_ner
