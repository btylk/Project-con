.. currentmodule:: pythainlp.change

pythainlp.change
====================================
The :class:`change` is fix incorrect input language correction.

Modules
-------

.. autofunction:: texttothai
.. autofunction:: texttoeng