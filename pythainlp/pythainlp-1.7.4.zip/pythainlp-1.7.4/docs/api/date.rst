.. currentmodule:: pythainlp.date


pythainlp.date
=====================================
The :class:`pythainlp.date` helps output dates, as spelled out in Thai.

.. autofunction:: now
