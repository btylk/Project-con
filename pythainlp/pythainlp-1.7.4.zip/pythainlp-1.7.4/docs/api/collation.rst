.. currentmodule:: pythainlp.collation


pythainlp.collation
=====================================
The :class:`pythainlp.collation` contains a function that sorts Thai text alphabetically

.. autofunction:: collation
