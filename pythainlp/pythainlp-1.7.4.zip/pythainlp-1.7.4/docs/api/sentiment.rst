.. currentmodule:: pythainlp.sentiment

pythainlp.sentiment
====================================
The :class:`romanization.sentiment` is sentiment analysis.

.. autofunction:: sentiment