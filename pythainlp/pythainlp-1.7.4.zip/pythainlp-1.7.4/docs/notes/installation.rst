Installation
=====================================
For stable version, try::

    pip install pythainlp

For developer version, try::

    pip install https://github.com/PyThaiNLP/pythainlp/archive/dev.zip

Note for Windows: marisa-trie wheels can be obtained from https://www.lfd.uci.edu/~gohlke/pythonlibs/#marisa-trie , then install it with pip, for example: `pip install marisa_trie‑0.7.5‑cp36‑cp36m‑win32.whl`