# มีอะไรใหม่ใน PyThaiNLP 1.7

## สรุปประเด็นสำคัญ

- ยกเลิกการสนับสนุน Python 2.7 อย่างเป็นทางการ
- เพิ่ม  ULMFit utility เข้ามาใน PyThaiNLP
- ปรับปรุงระบบตัดคำใหม่ ทั้ง newmm และ mm
- thai2vec v0.2
- sentiment analysis ตัวใหม่ทำงานด้วย Deep learning
- เพิ่ม thai2rom เป็น Thai Romanization ทำด้วย Deep learning ในระดับตัวอักษร



กำลังปรับปรุง...