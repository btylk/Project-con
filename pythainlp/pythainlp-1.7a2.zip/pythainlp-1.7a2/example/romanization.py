# -*- coding: utf-8 -*-
from pythainlp.romanization import romanization
print(romanization("แมว"))