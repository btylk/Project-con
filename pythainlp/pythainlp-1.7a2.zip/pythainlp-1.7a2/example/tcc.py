# -*- coding: utf-8 -*-
from pythainlp.tokenize import tcc
print(tcc.tcc('ประเทศไทย')) # ป/ระ/เท/ศ/ไท/ย