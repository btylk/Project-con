# -*- coding: utf-8 -*-
from pythainlp.tokenize import WhitespaceTokenizer
print(WhitespaceTokenizer("ทดสอบ ตัดคำช่องว่าง"))