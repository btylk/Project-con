# -*- coding: utf-8 -*-
from pythainlp.tokenize import etcc
print(etcc.etcc('คืนความสุข')) # /คืน/ความสุข