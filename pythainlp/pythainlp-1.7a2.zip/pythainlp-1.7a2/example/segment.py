# -*- coding: utf-8 -*-
from pythainlp.tokenize import word_tokenize
a =u'ฉันรักภาษาไทยเพราะฉันเป็นคนไทยและฉันใช้ภาษาไทย'
b = word_tokenize(a)
print(b)
