================
PyThaiNLP 1.6.0
================

Thai natural language processing in Python.

PyThaiNLP is a python module similar to nltk , but it's working primarily on

Thai language instead of English.

It supports both Python 2.7 and Python 3.


**Install**

pip install pythainlp


GitHub : https://github.com/wannaphongcom/pythainlp


**License**

Apache Software License 2.0
