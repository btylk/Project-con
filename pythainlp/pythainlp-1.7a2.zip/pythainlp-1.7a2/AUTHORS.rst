=======
Credits
=======

Development Lead
----------------

* Wannaphong Phatthiyaphaibun <wannaphong@kkumail.com>

* Korakot Chaovavanich

* Charin Polpanumas

* Peeradej Tanruangporn

NEWMM (ONECUT), MM , TCC & THAI SOUNDEX CODE
--------------------------------------------

* Korakot Chaovavanich

Thai2Vec & ulmfit
-----------------

* Charin Polpanumas

Docs
----

* Peeradej Tanruangporn

Contributors
------------

https://github.com/wannaphongcom/pythainlp/graphs/contributors
