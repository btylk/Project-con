# วิธีติดตั้ง PyThaiNLP เวชั่นล่าสุดจาก GitHub

ใช้คำสั่งนี้ในคอมมาไลน์

```
pip install -U https://github.com/wannaphongcom/pythainlp/archive/pythainlp1.4.zip
```